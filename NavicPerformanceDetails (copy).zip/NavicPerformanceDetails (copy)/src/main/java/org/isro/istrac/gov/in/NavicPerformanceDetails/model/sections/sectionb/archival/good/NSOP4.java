package org.isro.istrac.gov.in.NavicPerformanceDetails.model.sections.sectionb.archival.good;

import org.isro.istrac.gov.in.NavicPerformanceDetails.model.Status;
import org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer.ArchivalName;

public class NSOP4 extends NavigationArchival {
    public NSOP4(ArchivalName nsop4, Status status, String size) {
        super(nsop4, status, size);
    }
}
