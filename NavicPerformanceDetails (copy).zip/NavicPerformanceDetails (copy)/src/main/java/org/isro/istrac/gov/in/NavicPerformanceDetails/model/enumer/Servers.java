package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum Servers {
    INC1NSOP2,
    INC1NSOP4,
    INC2NSOP1,
    INC2NSOP2
}
