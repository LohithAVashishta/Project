package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum IrnssSatellite {
    SAT02,
    SAT03,
    SAT04,
    SAT06,
    SAT07,
    SAT10,

}
