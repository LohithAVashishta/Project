package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum ArchivalName {
    NSOP2,
    NSOP4,
    NSDAQ1,
    NSDAQ2
}
