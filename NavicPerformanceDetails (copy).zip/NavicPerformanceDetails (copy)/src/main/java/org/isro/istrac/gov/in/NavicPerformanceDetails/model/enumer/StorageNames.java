package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum StorageNames {
    ShiftOPs,
    NSOP1,
    NSOP2

}
