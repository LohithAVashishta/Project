package org.isro.istrac.gov.in.NavicPerformanceDetails.model.sections.sectionb.archival.good;

import org.isro.istrac.gov.in.NavicPerformanceDetails.model.Status;
import org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer.ArchivalName;


public class NSOP2 extends NavigationArchival {


    public NSOP2(ArchivalName nsop2, Status status, String size) {
        super(nsop2, status, size);
    }



}
