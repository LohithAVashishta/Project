package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum IrimsMode1Stn {
    BLR,
    LCK
}
