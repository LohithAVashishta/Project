package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum StationName {
    Bengaluru,
    Lucknow,
    Hassan,
    PortBlair,
    Delhi
}
