package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum IrimsChain {
    A,
    B
}
