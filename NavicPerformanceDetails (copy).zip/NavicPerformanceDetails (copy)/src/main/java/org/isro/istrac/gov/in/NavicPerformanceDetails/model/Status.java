package org.isro.istrac.gov.in.NavicPerformanceDetails.model;

public enum Status   {
    OK,
    NotOK,
    Unknown
}
