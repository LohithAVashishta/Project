package org.isro.istrac.gov.in.NavicPerformanceDetails.model;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NavicRepository extends JpaRepository<NavicPerformanceDetails, NavicPerformanceDetails>{
}


