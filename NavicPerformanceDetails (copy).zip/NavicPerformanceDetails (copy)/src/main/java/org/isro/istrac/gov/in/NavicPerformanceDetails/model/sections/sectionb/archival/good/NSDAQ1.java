package org.isro.istrac.gov.in.NavicPerformanceDetails.model.sections.sectionb.archival.good;

import org.isro.istrac.gov.in.NavicPerformanceDetails.model.Status;
import org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer.ArchivalName;

public class NSDAQ1 extends NavigationArchival {

    public NSDAQ1(ArchivalName nsdaq1, Status status, String size) {
        super(nsdaq1,status, size);
    }
}
