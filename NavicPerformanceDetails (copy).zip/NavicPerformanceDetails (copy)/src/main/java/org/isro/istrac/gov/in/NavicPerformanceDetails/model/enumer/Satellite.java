package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum Satellite {
    SAT02,
    SAT03,
    SAT06,
    SAT09
}
