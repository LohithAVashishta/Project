package org.isro.istrac.gov.in.NavicPerformanceDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NavicPerformanceDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NavicPerformanceDetailsApplication.class, args);
	}

}
