package org.isro.istrac.gov.in.NavicPerformanceDetails.model.enumer;

public enum NavigationServer {
    INC1_NSOP1,
    INC1_NSOP4,
    INC2_NSOP1,
    INC2_NSOP2


}
